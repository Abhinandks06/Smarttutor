import os
import json
from groq import Groq

# Initialize Groq client
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# 1. Doubt solving
def get_ai_answer(question: str) -> str:
    """
    Ask AI for an answer to a doubt/question.
    """
    try:
        response = client.chat.completions.create(
            model="llama3-8b-8192",
            messages=[
                {"role": "system", "content": "You are a helpful AI tutor."},
                {"role": "user", "content": question}
            ],
            max_tokens=300,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error: {str(e)}"


# 2. Quiz generation
def generate_quiz(topic: str) -> dict:
    """
    Generate a multiple-choice quiz in JSON format for a given topic.
    """
    prompt = f"""
    Create a multiple-choice quiz on {topic}. Return valid JSON:
    {{
      "title": "string",
      "questions": [
        {{"text": "string", "options": ["opt1","opt2","opt3","opt4"], "correct": "string", "explanation": "string"}}
      ]
    }}
    """
    try:
        response = client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7
        )
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        return {"error": str(e), "title": "", "questions": []}


# 3. Course suggestion
def suggest_course(weak_topics: list[str]) -> dict:
    """
    Suggest a compact course for a student weak in specific topics.
    """
    topics_str = ", ".join(weak_topics)
    prompt = f"""
    Suggest a compact course for a student weak in {topics_str}.
    Return valid JSON:
    {{
      "title": "string",
      "description": "string",
      "lessons": [{{"title": "string", "summary": "string", "content": "string (optional)"}}]
    }}
    """
    try:
        response = client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7
        )
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        return {"error": str(e), "title": "", "description": "", "lessons": []}
