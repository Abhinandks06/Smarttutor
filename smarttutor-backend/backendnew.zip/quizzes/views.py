from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404

from .models import Quiz, Question, Answer
from .serializers import QuizSerializer, QuestionSerializer, AnswerSerializer
from common.ai_service import generate_quiz  # returns JSON {title, questions:[{text, options[], correct, explanation}]}
from courses.models import Lesson

class QuizViewSet(viewsets.ModelViewSet):
    serializer_class = QuizSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Quiz.objects.filter(created_by=self.request.user).order_by('-created_at')

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class GenerateQuizAPIView(APIView):
    """
    POST /api/quizzes/generate/
    Body: {"topic": "Photosynthesis", "lesson_id": optional}
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        topic = (request.data.get('topic') or '').strip()
        if not topic:
            return Response({"error": "Provide 'topic'."}, status=400)

        lesson_id = request.data.get('lesson_id')
        lesson = None
        if lesson_id:
            lesson = get_object_or_404(Lesson, pk=lesson_id, course__created_by=request.user)

        data = generate_quiz(topic)
        quiz = Quiz.objects.create(
            created_by=request.user,
            title=data.get('title', f'Quiz on {topic}'),
            topic=topic,
            lesson=lesson
        )

        for q in data.get('questions', []):
            question = Question.objects.create(quiz=quiz, text=q.get('text', ''))
            # options list + correct string
            options = q.get('options', [])
            correct = q.get('correct', '')
            explanation = q.get('explanation', '')
            for opt in options:
                Answer.objects.create(
                    question=question,
                    text=opt,
                    is_correct=(opt == correct),
                    explanation=explanation if opt == correct else ''
                )

        return Response(QuizSerializer(quiz).data, status=201)
