from django.urls import path
from .views import SuggestionView

urlpatterns = [
    path("suggest/", SuggestionView.as_view(), name="suggestions"),
]
