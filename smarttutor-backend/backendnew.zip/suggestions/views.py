from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from courses.models import Course
from quizzes.models import Quiz

class SuggestionView(APIView):
    def post(self, request):
        query = request.data.get("query", "").strip().lower()

        if not query:
            return Response({"error": "Query is required"}, status=status.HTTP_400_BAD_REQUEST)

        # --- Courses (title + description if exists) ---
        course_matches = Course.objects.filter(title__icontains=query)
        if hasattr(Course, "description"):
            course_matches = course_matches | Course.objects.filter(description__icontains=query)

        courses = [{"id": c.id, "title": c.title, "description": getattr(c, "description", "")} for c in course_matches]

        # --- Quizzes (title + topic only, no description) ---
        quiz_matches = Quiz.objects.filter(title__icontains=query) | Quiz.objects.filter(topic__icontains=query)
        quizzes = [{"id": q.id, "title": q.title, "topic": q.topic} for q in quiz_matches]

        return Response({
            "query": query,
            "courses": courses,
            "quizzes": quizzes
        }, status=status.HTTP_200_OK)
