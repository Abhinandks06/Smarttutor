from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView
from django.shortcuts import get_object_or_404

from .models import Course, Lesson
from .serializers import CourseSerializer, LessonSerializer

# reuse AI functions from doubts.ai_service
from common.ai_service import suggest_course  # returns JSON {title, description, lessons:[{title, summary}]}

class CourseViewSet(viewsets.ModelViewSet):
    serializer_class = CourseSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Course.objects.filter(created_by=self.request.user).order_by('-created_at')

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

class LessonViewSet(viewsets.ModelViewSet):
    serializer_class = LessonSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Lesson.objects.filter(course__created_by=self.request.user)

class SuggestCourseAPIView(APIView):
    """
    POST /api/courses/suggest/
    Body: {"weak_topics": ["Algebra", "Trigonometry"]} OR {"topic": "Algebra basics"}
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        weak_topics = request.data.get('weak_topics')
        topic = request.data.get('topic')
        if not weak_topics and not topic:
            return Response({"error": "Provide 'weak_topics' (list) or 'topic' (string)."}, status=400)

        if weak_topics and not isinstance(weak_topics, list):
            return Response({"error": "'weak_topics' must be a list of strings."}, status=400)

        topics = weak_topics if weak_topics else [topic]
        data = suggest_course(topics)  # {title, description, lessons:[{title, summary}]}

        course = Course.objects.create(
            created_by=request.user,
            title=data.get('title', 'Personalized Course'),
            description=data.get('description', '')
        )
        for idx, l in enumerate(data.get('lessons', []), start=1):
            Lesson.objects.create(
                course=course,
                title=l.get('title', f'Lesson {idx}'),
                summary=l.get('summary', ''),
                content=l.get('content', ''),  # optional if your AI returns content
                order=idx
            )

        return Response(CourseSerializer(course).data, status=201)
