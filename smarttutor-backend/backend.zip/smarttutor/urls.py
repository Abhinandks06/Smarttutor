from django.contrib import admin
from django.urls import path, include
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

urlpatterns = [
    path('admin/', admin.site.urls),

    # doubts app
    path('api/doubts/', include('doubts.urls')),
    path('api/progress/', include('progress.urls')),

    # study program
    path('api/study/', include('study.urls')),

    # quiz
    path('api/quiz/', include('quiz.urls')),

    # progress tracker
    path('api/progress/', include('progress.urls')),

    # users app
    path('api/', include('users.urls')),

    # JWT
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]
