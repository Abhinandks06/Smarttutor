from rest_framework import serializers
from .models import (
    ChatSession, Doubt,
    StudyProgram, Lesson, Quiz, Question, Answer, Progress
)


# =======================
#  CHAT & DOUBT SYSTEM
# =======================

class ChatSessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChatSession
        fields = ["id", "title", "created_at", "user"]
        read_only_fields = ["id", "created_at", "user"]


class DoubtSerializer(serializers.ModelSerializer):
    class Meta:
        model = Doubt
        fields = ["id", "question", "answer", "session", "created_at", "user"]
        read_only_fields = ["id", "answer", "created_at", "user"]
        

# =======================
#  STUDY PROGRAM SYSTEM
# =======================

class LessonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Lesson
        fields = ["id", "program", "title", "content", "order"]


class StudyProgramSerializer(serializers.ModelSerializer):
    lessons = LessonSerializer(many=True, read_only=True)

    class Meta:
        model = StudyProgram
        fields = ["id", "title", "description", "created_by", "created_at", "lessons"]
        read_only_fields = ["id", "created_by", "created_at"]


class AnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Answer
        fields = ["id", "question", "text", "is_correct"]
        extra_kwargs = {"is_correct": {"write_only": True}}  # hide correct flag from students


class QuestionSerializer(serializers.ModelSerializer):
    answers = AnswerSerializer(many=True, read_only=True)

    class Meta:
        model = Question
        fields = ["id", "quiz", "text", "answers"]


class QuizSerializer(serializers.ModelSerializer):
    questions = QuestionSerializer(many=True, read_only=True)

    class Meta:
        model = Quiz
        fields = ["id", "lesson", "title", "questions"]


# =======================
#  PROGRESS TRACKING
# =======================

class ProgressSerializer(serializers.ModelSerializer):
    lesson_title = serializers.CharField(source="lesson.title", read_only=True)

    class Meta:
        model = Progress
        fields = ["id", "lesson", "lesson_title", "completed", "score", "user"]
        read_only_fields = ["id", "user", "lesson_title"]
