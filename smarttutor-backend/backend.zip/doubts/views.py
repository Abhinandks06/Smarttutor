from rest_framework import viewsets, generics, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from django.db.models import Q

from .models import (
    ChatSession, Doubt,
    StudyProgram, Lesson, Quiz, Question, Answer, Progress
)
from .serializers import (
    ChatSessionSerializer, DoubtSerializer,
    StudyProgramSerializer, LessonSerializer,
    QuizSerializer, QuestionSerializer, AnswerSerializer,
    ProgressSerializer
)


# ===========================
#  EXISTING AI DOUBT SYSTEM
# ===========================

class ChatSessionViewSet(viewsets.ModelViewSet):
    queryset = ChatSession.objects.all()
    serializer_class = ChatSessionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return ChatSession.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


class DoubtViewSet(viewsets.ModelViewSet):
    queryset = Doubt.objects.all()
    serializer_class = DoubtSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Doubt.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        # Here you can integrate AI model call to generate answer
        question = serializer.validated_data['question']
        # Dummy answer for now (replace with AI API call)
        ai_answer = f"AI-generated answer for: {question}"
        serializer.save(user=self.request.user, answer=ai_answer)


# ===========================
#   STUDY PROGRAM FEATURES
# ===========================

class StudyProgramViewSet(viewsets.ModelViewSet):
    queryset = StudyProgram.objects.all()
    serializer_class = StudyProgramSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return StudyProgram.objects.filter(created_by=self.request.user)

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)


class LessonViewSet(viewsets.ModelViewSet):
    queryset = Lesson.objects.all()
    serializer_class = LessonSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        # User can only view lessons in their own programs
        return Lesson.objects.filter(program__created_by=self.request.user)


class QuizViewSet(viewsets.ModelViewSet):
    queryset = Quiz.objects.all()
    serializer_class = QuizSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Quiz.objects.filter(lesson__program__created_by=self.request.user)


class QuestionViewSet(viewsets.ModelViewSet):
    queryset = Question.objects.all()
    serializer_class = QuestionSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Question.objects.filter(quiz__lesson__program__created_by=self.request.user)


class AnswerViewSet(viewsets.ModelViewSet):
    queryset = Answer.objects.all()
    serializer_class = AnswerSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Answer.objects.filter(question__quiz__lesson__program__created_by=self.request.user)


# ===========================
#   PROGRESS TRACKING
# ===========================

class ProgressViewSet(viewsets.ModelViewSet):
    queryset = Progress.objects.all()
    serializer_class = ProgressSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Progress.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)


# ===========================
#   CUSTOM QUIZ SUBMISSION
# ===========================

class SubmitQuizView(generics.GenericAPIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, quiz_id):
        quiz = get_object_or_404(Quiz, id=quiz_id)
        answers = request.data.get("answers", {})  # {question_id: answer_id}

        score = 0
        total = quiz.questions.count()

        for question in quiz.questions.all():
            selected_answer_id = answers.get(str(question.id))
            if selected_answer_id:
                answer = Answer.objects.filter(id=selected_answer_id, question=question).first()
                if answer and answer.is_correct:
                    score += 1

        percentage = (score / total * 100) if total > 0 else 0

        # Save/update progress
        progress, created = Progress.objects.get_or_create(
            user=request.user,
            lesson=quiz.lesson,
            defaults={"completed": True, "score": percentage}
        )
        if not created:
            progress.completed = True
            progress.score = percentage
            progress.save()

        return Response({
            "score": score,
            "total": total,
            "percentage": percentage,
        }, status=status.HTTP_200_OK)
