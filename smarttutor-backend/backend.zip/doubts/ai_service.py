import json
from groq import Groq
import os

# Make sure you set GROQ_API_KEY in your environment variables
client = Groq(api_key=os.getenv("GROQ_API_KEY"))


# =======================
#   AI DOUBT ANSWER
# =======================
def get_ai_answer(question: str) -> str:
    """Answer student doubt using AI model"""
    try:
        response = client.chat.completions.create(
            model="llama3-8b-8192",  # or llama3-70b-8192 for better quality
            messages=[
                {"role": "system", "content": "You are a helpful AI tutor."},
                {"role": "user", "content": question}
            ],
            max_tokens=300,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        return f"Error: {str(e)}"


# =======================
#   AI QUIZ GENERATION
# =======================
def generate_quiz(topic: str):
    """Generate quiz questions on a given topic"""
    prompt = f"""
    Create a quiz on {topic}. Return in JSON format:
    {{
      "title": "string",
      "questions": [
        {{
          "text": "string",
          "options": ["opt1", "opt2", "opt3", "opt4"],
          "correct": "string",
          "explanation": "string"
        }}
      ]
    }}
    """
    response = client.chat.completions.create(
        model="llama3-70b-8192",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    return json.loads(response.choices[0].message.content)


# =======================
#   AI COURSE SUGGESTION
# =======================
def suggest_course(weak_topics: list[str]):
    """Suggest a personalized course for weak topics"""
    topics_str = ", ".join(weak_topics)
    prompt = f"""
    Suggest a personalized course for a student weak in {topics_str}.
    Return JSON:
    {{
      "title": "string",
      "description": "string",
      "lessons": [
        {{"title": "string", "summary": "string"}}
      ]
    }}
    """
    response = client.chat.completions.create(
        model="llama3-70b-8192",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    return json.loads(response.choices[0].message.content)
