import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import {
  FaSearch,
  FaCopy,
  FaSignOutAlt,
  FaPaperPlane,
  FaUserCircle,
  FaChalkboardTeacher,
} from "react-icons/fa";
import bg from "../assets/smart-tutor-bg.png";
import "./AskDoubt.css";

const API_BASE = process.env.REACT_APP_API_URL || "http://127.0.0.1:8000";

export default function AskDoubt() {
  const [history, setHistory] = useState([]);
  const [selected, setSelected] = useState(null); // selected history id
  const [messages, setMessages] = useState([]); // [{role:'user'|'bot', text: ''}]
  const [input, setInput] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef(null);

  // helper to get token and headers
  const headers = () => {
    const token = localStorage.getItem("access");
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  useEffect(() => {
    // always scroll to bottom when messages change
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function fetchHistory() {
    try {
      const res = await axios.get(`${API_BASE}/api/doubts/history/`, {
        headers: headers(),
      });
      // ensure newest-first display (server already returns newest first, but normalize)
      setHistory(res.data);
    } catch (err) {
      console.error("History fetch error:", err);
      // optional: show a small UI hint or fallback
    }
  }

  function openHistoryItem(item) {
    setSelected(item.id);
    // populate messages with that Q&A
    setMessages([
      { role: "user", text: item.question },
      { role: "bot", text: item.answer || "No answer stored." },
    ]);
    // scroll happens in useEffect
  }

  async function handleSend(e) {
    e?.preventDefault?.();
    const text = input.trim();
    if (!text) return;

    // optimistic UI: append user message
    setMessages((m) => [...m, { role: "user", text }]);
    setInput("");
    setLoading(true);
    setTyping(true);

    try {
      const res = await axios.post(
        `${API_BASE}/api/doubts/`,
        { question: text },
        { headers: { ...headers(), "Content-Type": "application/json" } }
      );

      const answer = res.data.answer ?? "No answer returned.";
      // replace "thinking" with actual answer: append bot message
      setMessages((m) => [...m.filter(x => !(x.role === 'bot' && x.text === '...thinking...')), { role: "bot", text: answer }]);
      setSelected(res.data.id ?? null);

      // refetch history so left panel updates
      fetchHistory();
    } catch (err) {
      console.error("Send error:", err);
      setMessages((m) => [...m, { role: "bot", text: "❌ Failed to get an answer. Try again." }]);
    } finally {
      setLoading(false);
      setTyping(false);
    }
  }

  function handleCopy(txt) {
    if (!navigator.clipboard) {
      alert("Clipboard not supported");
      return;
    }
    navigator.clipboard.writeText(txt).then(() => {
      // quick toast
      const el = document.createElement("div");
      el.className = "st-copy-toast";
      el.innerText = "Copied!";
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 900);
    });
  }

  function handleLogout() {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    window.location.href = "/login";
  }

  const filtered = history.filter((h) =>
    h.question.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="st-root">
      {/* LEFT: History panel */}
      <aside className="st-left">
        <div className="st-left-top">
          <div className="st-brand">
            <FaChalkboardTeacher className="st-brand-icon" />
            <div className="st-brand-text">Smart Tutor</div>
          </div>
          <button className="st-logout" onClick={handleLogout} title="Logout">
            <FaSignOutAlt />
          </button>
        </div>

        <div className="st-search">
          <FaSearch className="st-search-icon" />
          <input
            placeholder="Search history..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="st-history-list">
          {filtered.length === 0 ? (
            <div className="st-history-empty">No history yet</div>
          ) : (
            filtered.map((h) => (
              <button
                key={h.id}
                className={`st-history-item ${selected === h.id ? "selected" : ""}`}
                onClick={() => openHistoryItem(h)}
              >
                <div className="st-hi-left"><FaUserCircle /></div>
                <div className="st-hi-right">
                  <div className="st-hi-q">{h.question}</div>
                  <div className="st-hi-meta">{new Date(h.created_at).toLocaleString()}</div>
                </div>
              </button>
            ))
          )}
        </div>
      </aside>

      {/* RIGHT: Chat area (background only) */}
      <main className="st-right">
        {/* background image layer */}
        <div
          className="st-bg"
          style={{ backgroundImage: `url(${bg})` }}
          aria-hidden="true"
        />
        {/* translucent overlay so text is readable */}
        <div className="st-overlay" />

        {/* chat content */}
        <section className="st-chat">

          <div className="st-messages" role="log" aria-live="polite">
            {messages.map((m, i) => (
              <div key={i} className={`st-msg ${m.role === "user" ? "user" : "bot"}`}>
                <div className="st-avatar">{m.role === "user" ? <FaUserCircle /> : <FaChalkboardTeacher />}</div>

                <div className="st-bubble">
                  <div className="st-txt">{m.text}</div>
                  {m.role === "bot" && (
                    <button className="st-copy" onClick={() => handleCopy(m.text)} aria-label="Copy answer">
                      <FaCopy />
                    </button>
                  )}
                </div>
              </div>
            ))}

            {typing && (
              <div className="st-msg bot typing">
                <div className="st-avatar"><FaChalkboardTeacher /></div>
                <div className="st-bubble">
                  <div className="st-typing-dots">
                    <span /><span /><span />
                  </div>
                </div>
              </div>
            )}

            <div ref={scrollRef => (scrollRef ? (scrollRef.current = scrollRef) : null)} />
            <div ref={scrollRef} />
            <div ref={scrollRef} />
          </div>

          {/* input area - sticky */}
          <form className="st-input-area" onSubmit={(e) => { e.preventDefault(); handleSend(); }}>
            <textarea
              className="st-input"
              placeholder="Ask your tutor..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              rows={1}
            />
            <button className="st-send" type="submit" disabled={loading}>
              <FaPaperPlane />
            </button>
          </form>
        </section>
      </main>
    </div>
  );
}
