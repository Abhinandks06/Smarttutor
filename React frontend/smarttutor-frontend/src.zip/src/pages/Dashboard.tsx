import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ActionButtons from "../components/ActionButtons";
import ProgressCard from "../components/ProgressCard";
import ActivityList from "../components/ActivityList";
import "./Dashboard.css";

export default function Dashboard() {
  const navigate = useNavigate();

  useEffect(() => {
    const accessToken = localStorage.getItem("access");
    if (!accessToken) {
      navigate("/login");
    }
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    navigate("/login");
  };

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div className="header-content">
          <h1 className="welcome-title">Welcome to SmartTutor 🎓</h1>
          <p className="welcome-subtitle">You are successfully logged in!</p>
          <button className="logout-btn" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </header>

      <main className="dashboard-main">
        <div className="dashboard-container">
          <ActionButtons navigate={navigate} />
          
          <div className="dashboard-grid">
            <ProgressCard />
            <ActivityList />
          </div>
        </div>
      </main>
    </div>
  );
}